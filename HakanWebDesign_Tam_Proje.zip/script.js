/* =====================================================
   HAKANWEBDESIGN
   INTERACTIONS
===================================================== */


document.addEventListener("DOMContentLoaded", () => {


    /* =================================================
       MOBILE MENU
    ================================================= */

    const menuButton =
        document.getElementById("menuButton");

    const navLinks =
        document.getElementById("navLinks");


    if (menuButton && navLinks) {

        menuButton.addEventListener(
            "click",
            () => {

                navLinks.classList.toggle("active");

            }
        );


        navLinks
            .querySelectorAll("a")
            .forEach(link => {

                link.addEventListener(
                    "click",
                    () => {

                        navLinks.classList.remove(
                            "active"
                        );

                    }
                );

            });

    }


    /* =================================================
       NAVBAR SCROLL
    ================================================= */

    const navbar =
        document.getElementById("navbar");


    function updateNavbar() {

        if (!navbar) return;


        if (window.scrollY > 60) {

            navbar.classList.add(
                "scrolled"
            );

        } else {

            navbar.classList.remove(
                "scrolled"
            );

        }

    }


    window.addEventListener(
        "scroll",
        updateNavbar
    );


    updateNavbar();


    /* =================================================
       SCROLL PROGRESS
    ================================================= */

    const scrollProgress =
        document.getElementById(
            "scrollProgress"
        );


    function updateScrollProgress() {

        if (!scrollProgress) return;


        const scrollTop =
            window.scrollY;


        const documentHeight =
            document.documentElement
                .scrollHeight -
            window.innerHeight;


        if (documentHeight <= 0) return;


        const percentage =
            (scrollTop / documentHeight) *
            100;


        scrollProgress.style.width =
            percentage + "%";

    }


    window.addEventListener(
        "scroll",
        updateScrollProgress
    );


    updateScrollProgress();


    /* =================================================
       REVEAL ANIMATIONS
    ================================================= */

    const revealElements =
        document.querySelectorAll(
            ".reveal, .reveal-left, .reveal-right"
        );


    const revealObserver =
        new IntersectionObserver(

            (entries, observer) => {

                entries.forEach(
                    entry => {

                        if (
                            entry.isIntersecting
                        ) {

                            entry.target
                                .classList
                                .add("show");


                            observer.unobserve(
                                entry.target
                            );

                        }

                    }
                );

            },

            {
                threshold: 0.12
            }

        );


    revealElements.forEach(
        element => {

            revealObserver.observe(
                element
            );

        }
    );


    /* =================================================
       COUNTERS
    ================================================= */

    const counters =
        document.querySelectorAll(
            ".counter"
        );


    let countersStarted = false;


    function startCounters() {

        if (countersStarted) return;

        countersStarted = true;


        counters.forEach(
            counter => {

                const target =
                    Number(
                        counter.dataset.target
                    );


                let current = 0;


                const duration = 1400;

                const increment =
                    target /
                    (duration / 16);


                function updateCounter() {

                    current += increment;


                    if (current >= target) {

                        counter.textContent =
                            target;

                        return;

                    }


                    counter.textContent =
                        Math.floor(current);


                    requestAnimationFrame(
                        updateCounter
                    );

                }


                updateCounter();

            }
        );

    }


    const hero =
        document.querySelector(
            ".hero"
        );


    if (hero) {

        const counterObserver =
            new IntersectionObserver(

                entries => {

                    if (
                        entries[0]
                            .isIntersecting
                    ) {

                        startCounters();

                    }

                },

                {
                    threshold: 0.4
                }

            );


        counterObserver.observe(hero);

    }


    /* =================================================
       SMOOTH ANCHOR
    ================================================= */

    document
        .querySelectorAll(
            'a[href^="#"]'
        )
        .forEach(anchor => {

            anchor.addEventListener(
                "click",
                function(event) {

                    const targetId =
                        this.getAttribute(
                            "href"
                        );


                    if (
                        !targetId ||
                        targetId === "#"
                    ) {

                        return;

                    }


                    const target =
                        document.querySelector(
                            targetId
                        );


                    if (!target) return;


                    event.preventDefault();


                    const offset = 75;


                    const targetPosition =
                        target.getBoundingClientRect()
                            .top +
                        window.scrollY -
                        offset;


                    window.scrollTo({

                        top:
                            targetPosition,

                        behavior:
                            "smooth"

                    });

                }
            );

        });


    /* =================================================
       MOUSE GLOW
    ================================================= */

    const cursorGlow =
        document.getElementById(
            "cursorGlow"
        );


    if (
        cursorGlow &&
        window.matchMedia(
            "(pointer: fine)"
        ).matches
    ) {

        let mouseX = 0;
        let mouseY = 0;

        let currentX = 0;
        let currentY = 0;


        document.addEventListener(
            "mousemove",
            event => {

                mouseX =
                    event.clientX;

                mouseY =
                    event.clientY;

            }
        );


        function animateGlow() {

            currentX +=
                (mouseX - currentX)
                * 0.12;


            currentY +=
                (mouseY - currentY)
                * 0.12;


            cursorGlow.style.left =
                currentX + "px";


            cursorGlow.style.top =
                currentY + "px";


            requestAnimationFrame(
                animateGlow
            );

        }


        animateGlow();

    }


    /* =================================================
       PROJECT 3D EFFECT
    ================================================= */

    const projectCards =
        document.querySelectorAll(
            ".project-card"
        );


    projectCards.forEach(
        card => {

            card.addEventListener(
                "mousemove",
                event => {

                    if (
                        window.innerWidth < 850
                    ) {

                        return;

                    }


                    const rect =
                        card.getBoundingClientRect();


                    const x =
                        event.clientX -
                        rect.left;


                    const y =
                        event.clientY -
                        rect.top;


                    const centerX =
                        rect.width / 2;


                    const centerY =
                        rect.height / 2;


                    const rotateX =
                        ((y - centerY) /
                            centerY) *
                        -3;


                    const rotateY =
                        ((x - centerX) /
                            centerX) *
                        3;


                    card.style.transform =
                        `
                        perspective(1000px)
                        rotateX(${rotateX}deg)
                        rotateY(${rotateY}deg)
                        translateY(-5px)
                        `;

                }
            );


            card.addEventListener(
                "mouseleave",
                () => {

                    card.style.transform =
                        "";

                }
            );

        }
    );


    /* =================================================
       SERVICE CARD LIGHT
    ================================================= */

    const serviceCards =
        document.querySelectorAll(
            ".service-card"
        );


    serviceCards.forEach(
        card => {

            card.addEventListener(
                "mousemove",
                event => {

                    const rect =
                        card.getBoundingClientRect();


                    const x =
                        event.clientX -
                        rect.left;


                    const y =
                        event.clientY -
                        rect.top;


                    card.style.setProperty(
                        "--mouse-x",
                        x + "px"
                    );


                    card.style.setProperty(
                        "--mouse-y",
                        y + "px"
                    );

                }
            );

        }
    );


    /* =================================================
       CONTACT FORM → WHATSAPP
    ================================================= */

    const contactForm =
        document.getElementById(
            "contactForm"
        );


    if (contactForm) {

        contactForm.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const name =
                    document
                        .getElementById("name")
                        .value
                        .trim();


                const email =
                    document
                        .getElementById("email")
                        .value
                        .trim();


                const phone =
                    document
                        .getElementById("phone")
                        .value
                        .trim();


                const service =
                    document
                        .getElementById("service")
                        .value
                        .trim();


                const message =
                    document
                        .getElementById("message")
                        .value
                        .trim();


                const whatsappNumber =
                    "905510551297";


                const whatsappMessage =
                    `Merhaba HakanWebDesign,

Yeni bir web sitesi projesi hakkında bilgi almak istiyorum.

Ad Soyad: ${name}

E-posta: ${email}

Telefon: ${phone || "Belirtilmedi"}

İlgilendiğim hizmet: ${service || "Belirtilmedi"}

Projem:
${message}

Teşekkürler.`;


                const encodedMessage =
                    encodeURIComponent(
                        whatsappMessage
                    );


                const whatsappURL =
                    `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;


                window.open(
                    whatsappURL,
                    "_blank"
                );

            }
        );

    }


    /* =================================================
       PARALLAX HERO
    ================================================= */

    const heroVisual =
        document.querySelector(
            ".hero-visual"
        );


    if (
        heroVisual &&
        window.innerWidth > 850
    ) {

        window.addEventListener(
            "scroll",
            () => {

                const scroll =
                    window.scrollY;


                if (scroll > 800) return;


                const movement =
                    scroll * 0.12;


                heroVisual.style.transform =
                    `translateY(${movement}px)`;

            }
        );

    }


    /* =================================================
       PROCESS SCROLL EFFECT
    ================================================= */

    const processItems =
        document.querySelectorAll(
            ".process-item"
        );


    processItems.forEach(
        (item, index) => {

            item.style.transitionDelay =
                `${index * 0.08}s`;

        }
    );


    /* =================================================
       FOOTER YEAR
    ================================================= */

    const footerText =
        document.querySelector(
            ".footer-bottom span"
        );


    if (footerText) {

        const year =
            new Date()
                .getFullYear();


        footerText.textContent =
            `© ${year} HakanWebDesign. Tüm hakları saklıdır.`;

    }


    /* =================================================
       PAGE LOADED
    ================================================= */

    document.body.classList.add(
        "page-loaded"
    );


    console.log(
        "HakanWebDesign — Premium Web Experience"
    );

});